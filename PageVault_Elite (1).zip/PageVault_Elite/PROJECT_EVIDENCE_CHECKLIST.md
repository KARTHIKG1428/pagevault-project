# PageVault evidence checklist

## Requirements
- [ ] Register and sign in
- [ ] Add book with title, author, edition, ISBN, course code and condition
- [ ] Search by title, author and course code; test filters and pagination
- [ ] Request a book; verify status changes atomically to Reserved
- [ ] Try a second request for the same book from another account; verify conflict response
- [ ] Approve, reject and return a loan; verify book and loan records stay in sync
- [ ] Verify seven-day due date and overdue display
- [ ] Wishlist and borrowing history work
- [ ] Open Library ISBN lookup returns metadata or a clear not-found response
- [ ] Recommendations show a reason for each result

## Quality and architecture
- [ ] Explain routes → services → models separation
- [ ] Show frontend modules and API client
- [ ] Run `npm test`; capture terminal output
- [ ] Show Pino structured log output and request ID
- [ ] Show `/api/health` and `/api/ready`
- [ ] Show MongoDB indexes and persisted documents

## Security and reliability
- [ ] Protected route without token returns 401
- [ ] Non-owner cannot edit a listing or decide a request
- [ ] Wrong password is rejected
- [ ] Invalid course code is rejected server-side
- [ ] `.env` is not committed
- [ ] Disconnect/reconnect database and inspect logs/readiness

## Innovation
- [ ] Demonstrate Open Library ISBN metadata enrichment
- [ ] Demonstrate relevance-ranked recommendations and explain score factors
- [ ] Explain atomic reservation and transaction consistency
