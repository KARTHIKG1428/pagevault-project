# PageVault — OpenShelf Campus Exchange (Elite Edition)

Presented by **G. Karthik**. A modular campus textbook-sharing platform using HTML, CSS, JavaScript, Node.js, Express and MongoDB.

## What is improved in this edition
- Open Library ISBN lookup (`/api/integrations/open-library/:isbn`) with graceful fallback when a title has no external metadata.
- Explainable recommendation engine ranks available books using course-code, title and author relevance.
- Modular frontend (`api.js`, `catalog.js`, `dashboard.js`, `auth.js`) instead of one large `app.js`.
- Pino structured JSON logging and request IDs.
- Atomic book reservation (`findOneAndUpdate`) prevents two students from reserving the same book.
- MongoDB transaction for approve/return workflows so loan and book state remain consistent. MongoDB transactions require a replica set; use MongoDB Atlas or configure a local replica set.
- Database connection monitoring, graceful shutdown, health/readiness endpoints, pagination and indexes.
- Security: bcrypt, JWT, role/ownership checks, Helmet, rate limiting, validation, bounded request bodies and safe DOM rendering.
- Unit and API tests, seed data (35 books), evidence checklist and demo script.

## Requirements
Node.js 18+, npm, MongoDB replica set (local or Atlas), VS Code.

## Setup in VS Code
1. Extract the ZIP and open the `PageVault_Elite` folder in VS Code.
2. Open Terminal and run `npm install`.
3. Copy `.env.example` to `.env`. Set a unique `JWT_SECRET` (32+ characters) and your MongoDB URI.
4. For a local MongoDB replica set, start MongoDB with `--replSet rs0`, then run `mongosh` and execute `rs.initiate()` once. Alternatively use an Atlas connection string.
5. Run `npm run seed` to add 35 sample books and a demo administrator.
6. Run `npm run dev`; open http://localhost:5000.
7. Run `npm test` to execute automated tests.

### Demo account
- Email: `admin@pagevault.demo`
- Password: `Admin@12345`
- Change or remove this demo account before any real deployment.

## Student demo flow
Register Student B → search `CSE301` → request a book → sign in as the owner/admin → approve → return to borrower account → show the 7-day due date → mark returned. Also demonstrate ISBN lookup and recommendations.

## API overview
| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/health` | Process health |
| GET | `/api/ready` | Database readiness |
| POST | `/api/auth/register` | Student registration |
| POST | `/api/auth/login` | Login |
| GET | `/api/auth/me` | Current user |
| GET | `/api/books` | Search, filter, paginate catalogue |
| POST | `/api/books` | Add book |
| PATCH | `/api/books/:id` | Edit owned listing |
| DELETE | `/api/books/:id` | Delete available owned listing |
| POST | `/api/loans/:bookId/request` | Atomic borrow request |
| GET | `/api/loans/mine` | Borrowing history |
| GET | `/api/loans/incoming` | Incoming requests |
| PATCH | `/api/loans/:id/decision` | Approve/reject transactionally |
| PATCH | `/api/loans/:id/return` | Return transactionally |
| GET/POST/DELETE | `/api/wishlist` | Wishlist |
| GET | `/api/recommendations` | Explainable book recommendations |
| GET | `/api/integrations/open-library/:isbn` | Open Library metadata lookup |

## Important academic note
Course prefixes in `src/utils/courseCodes.js` are starter values. Replace them with your college's official taxonomy. External Open Library results are optional enrichment, not a substitute for locally stored book records. Due reminders are calculated from the persisted due date when the dashboard loads; this project does not claim to send email/SMS in the background.

## Evaluation evidence
Use `PROJECT_EVIDENCE_CHECKLIST.md`. Capture real screenshots of successful tests, API responses, MongoDB records and the running UI. Do not mark a checklist item complete until you have tested it on your machine.
