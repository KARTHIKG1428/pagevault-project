const API='/api';let token=localStorage.getItem('pv_token')||'';
export function setToken(value){token=value||'';if(token)localStorage.setItem('pv_token',token);else localStorage.removeItem('pv_token');}
export function getToken(){return token;}
export async function api(path,options={}){const headers={'Content-Type':'application/json',...(options.headers||{})};if(token)headers.Authorization=`Bearer ${token}`;const response=await fetch(API+path,{...options,headers});const data=await response.json().catch(()=>({}));if(!response.ok)throw new Error(data.message||`Request failed (${response.status})`);return data;}
export const escapeHTML=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
