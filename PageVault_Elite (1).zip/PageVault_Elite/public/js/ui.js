export const $=id=>document.getElementById(id);
export function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600);}
export function empty(message){return `<div class="empty">${message}</div>`;}
