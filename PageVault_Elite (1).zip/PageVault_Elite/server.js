require('dotenv').config();
const mongoose = require('mongoose');
const app = require('./src/app');
const { logger } = require('./src/utils/logger');
const PORT = process.env.PORT || 5000;

async function start() {
  try {
    mongoose.set('strictQuery', true);
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/pagevault?replicaSet=rs0', { serverSelectionTimeoutMS: 10000 });
    logger.info({ event: 'database_connected' }, 'MongoDB connected');
    const server = app.listen(PORT, () => logger.info({ port: PORT }, `PageVault listening on ${PORT}`));
    const shutdown = async signal => {
      logger.info({ signal }, 'Graceful shutdown started');
      server.close(async () => { await mongoose.disconnect(); process.exit(0); });
      setTimeout(() => process.exit(1), 10000).unref();
    };
    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
    mongoose.connection.on('disconnected', () => logger.warn({ event: 'database_disconnected' }, 'MongoDB disconnected'));
    mongoose.connection.on('reconnected', () => logger.info({ event: 'database_reconnected' }, 'MongoDB reconnected'));
  } catch (err) { logger.fatal({ err }, 'Startup failed'); process.exit(1); }
}
start();
