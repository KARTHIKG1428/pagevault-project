const mongoose = require('mongoose');
const { logger } = require('../utils/logger');
async function connectDB() { await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/pagevault?replicaSet=rs0', { serverSelectionTimeoutMS: 10000 }); logger.info('MongoDB connected'); }
module.exports = connectDB;
