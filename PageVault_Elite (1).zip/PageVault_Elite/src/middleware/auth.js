const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('./asyncHandler');
exports.protect = asyncHandler(async (req,res,next) => {
  const h = req.headers.authorization || ''; if (!h.startsWith('Bearer ')) return res.status(401).json({message:'Authentication required'});
  let payload; try { payload = jwt.verify(h.slice(7), process.env.JWT_SECRET); } catch { return res.status(401).json({message:'Invalid or expired token'}); }
  const user = await User.findById(payload.sub); if (!user) return res.status(401).json({message:'Account no longer exists'}); req.user=user; next();
});
exports.adminOnly = (req,res,next) => req.user?.role === 'admin' ? next() : res.status(403).json({message:'Administrator access required'});
