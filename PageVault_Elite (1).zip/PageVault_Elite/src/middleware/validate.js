const { validationResult } = require('express-validator');
module.exports = (req,res,next) => { const errors=validationResult(req); if(!errors.isEmpty()) return res.status(400).json({message:'Please correct the submitted fields',errors:errors.array()}); next(); };
