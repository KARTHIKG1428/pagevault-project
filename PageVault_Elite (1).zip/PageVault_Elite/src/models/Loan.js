const mongoose=require('mongoose');
const schema=new mongoose.Schema({book:{type:mongoose.Schema.Types.ObjectId,ref:'Book',required:true,index:true},borrower:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true},owner:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true,index:true},status:{type:String,enum:['Pending','Approved','Rejected','Returned'],default:'Pending',index:true},requestedAt:{type:Date,default:Date.now},approvedAt:Date,dueDate:Date,returnedAt:Date},{timestamps:true});
schema.index({book:1,status:1}); schema.index({borrower:1,createdAt:-1});
module.exports=mongoose.model('Loan',schema);
