const mongoose=require('mongoose');
const schema=new mongoose.Schema({name:{type:String,required:true,trim:true,minlength:2,maxlength:60},email:{type:String,required:true,unique:true,lowercase:true,trim:true},password:{type:String,required:true,select:false},role:{type:String,enum:['student','admin'],default:'student'},courseCode:{type:String,required:true,uppercase:true,trim:true}},{timestamps:true});
module.exports=mongoose.model('User',schema);
