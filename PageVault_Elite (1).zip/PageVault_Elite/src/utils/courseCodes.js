const COURSE_PREFIXES = ['CS','CSE','IT','ECE','EEE','ME','CE','AI','AIML','DS','MBA','MATH'];
function normalizeCourseCode(value) { return String(value || '').trim().toUpperCase().replace(/\s+/g, ''); }
function isValidCourseCode(value) { const code = normalizeCourseCode(value); return COURSE_PREFIXES.some(p => new RegExp(`^${p}[0-9]{2,4}[A-Z]?$`).test(code)); }
module.exports = { COURSE_PREFIXES, normalizeCourseCode, isValidCourseCode };
