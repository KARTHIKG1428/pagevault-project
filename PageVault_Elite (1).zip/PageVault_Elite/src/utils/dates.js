function calculateDueDate(from = new Date(), days = Number(process.env.LOAN_DAYS || 7)) { const d = new Date(from); d.setDate(d.getDate() + days); return d; }
function getLoanCondition(dueDate, now = new Date()) { if (!dueDate) return 'Unknown'; return new Date(dueDate) < now ? 'Overdue' : 'On time'; }
function daysRemaining(dueDate, now = new Date()) { return Math.ceil((new Date(dueDate) - now) / 86400000); }
module.exports = { calculateDueDate, getLoanCondition, daysRemaining };
