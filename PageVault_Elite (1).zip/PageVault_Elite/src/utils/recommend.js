function scoreBook(book, profile = {}) {
  const course = String(profile.courseCode || '').toUpperCase();
  const query = String(profile.query || '').toLowerCase();
  const interests = (profile.interests || []).map(x => String(x).toLowerCase()).filter(Boolean);
  const bookText = `${book.title || ''} ${book.author || ''}`.toLowerCase();
  let score = 0; const reasons = [];
  if (course && String(book.courseCode || '').toUpperCase() === course) { score += 60; reasons.push('Matches your course'); }
  else if (course && String(book.courseCode || '').toUpperCase().slice(0, 2) === course.slice(0, 2)) { score += 20; reasons.push('Same academic department'); }
  if (query && bookText.includes(query)) { score += 30; reasons.push('Matches your search interest'); }
  if (interests.some(term => term.length > 2 && bookText.includes(term))) { score += 25; reasons.push('Related to your wishlist'); }
  if (book.status === 'Available') { score += 10; reasons.push('Available to borrow'); }
  if (book.condition === 'New' || book.condition === 'Like New') score += 3;
  return { score, reasons: reasons.length ? reasons : ['Relevant campus catalogue match'] };
}
function rankBooks(books, profile) { return books.map(book => ({ book, ...scoreBook(book, profile) })).sort((a,b) => b.score-a.score); }
module.exports = { scoreBook, rankBooks };
